import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.*;
import java.util.stream.IntStream;

public class Main {
    private static final int DURATION = 5;
    private static final Random random = new Random();
    private static final CyclicBarrier professorBarrier = new CyclicBarrier(2);
    private static final ThreadPoolExecutor threadPool = (ThreadPoolExecutor) Executors.newFixedThreadPool(20);
    private static int totalScore = 0;
    private static int studentCount = 0;
    private static volatile long startTime = 0;
    private static final Object lock = new Object();

    public static void main(String[] args) throws InterruptedException {
        int N = 100;

        if (args.length == 1) {
            N = Integer.parseInt(args[0]);
        }
        else {
            System.out.println("Invalid arguments given running with default arguments(100)");
        }

        List<Callable<Integer>> students = new ArrayList<>();
        IntStream.range(0, N).forEach(_ -> students.add(Main::delegateDefence));

        startTime = System.currentTimeMillis();
        threadPool.invokeAll(students, DURATION, TimeUnit.SECONDS);

        double averageScore = studentCount > 0 ? (double) totalScore / studentCount : 0;
        System.out.println(studentCount);
        System.out.println("Average Score: " + averageScore);
    }

    private static int delegateDefence() {
        try {
            long arrivalTime = System.currentTimeMillis() - startTime;
            Thread.sleep((long) (random.nextDouble() * 1000));

            boolean goesToProfessor = random.nextBoolean();
            if (goesToProfessor) {
                professorBarrier.await();
                defendAndGrade(arrivalTime);
            }
            else {
                synchronized (lock) {
                    defendAndGrade(arrivalTime);
                }
            }

            return 1;
        } catch (InterruptedException | BrokenBarrierException ignored) {
            return 0;
        }
    }

    private static void defendAndGrade(long arrivalTime) throws InterruptedException {
        long defenseStartTime = System.currentTimeMillis() - startTime;
        long reviewTime = 500 + random.nextInt(501);
        Thread.sleep(reviewTime);

        int score = 5 + random.nextInt(6);
        addScore(score);

        String str = Thread.currentThread().getName();

        System.out.println(
                "Thread: " + Thread.currentThread().getName() +
                " Arrival: " + arrivalTime +
                " Prof: " + str +
                " TTC: " + reviewTime +
                ":" + defenseStartTime +
                " Score: " + score);
    }

    private static synchronized void addScore(int score) {
        totalScore += score;
        studentCount++;
    }
}
