export interface Comment {
    author: string;
    content: string;
}

export interface Post {
    id: number;
    author: string;
    title: string;
    content: string;
    date: string;
    comments: Comment[];
}
