import React, { useState } from 'react';
import PostList from './components/PostList';
import PostDetails from './components/PostDetails';
import NewPostForm from './components/NewPostForm';

const App: React.FC = () => {
    const [selectedPostId, setSelectedPostId] = useState<number | null>(null);
    const [adding, setAdding] = useState(false);

    return (
        <div className="app-container">
            {adding ? (
                <NewPostForm onDone={() => { setAdding(false); setSelectedPostId(null); }} />
            ) : selectedPostId ? (
                <PostDetails id={selectedPostId} onBack={() => setSelectedPostId(null)} />
            ) : (
                <PostList onSelect={setSelectedPostId} onNew={() => setAdding(true)} />
            )}
        </div>
    );
};
export default App;
