import axios from 'axios';
import type {Post, Comment} from '../types';

const API = "http://localhost:8080/api/posts";

function getErrorMessage(error: unknown): string {
    if (axios.isAxiosError(error)) {
        if (error.response) {
            return `Error ${error.response.status}: ${error.response.data?.message || error.response.statusText}`;
        } else if (error.request) {
            return "No answer from server";
        } else {
            return error.message;
        }
    }
    return String(error);
}

export async function getPosts(): Promise<Post[]> {
    try {
        const res = await axios.get<Post[]>(API);
        return res.data;
    } catch (error) {
        console.error("Error cant get resource:", error);
        throw new Error(getErrorMessage(error));
    }
}

export async function getPost(id: number): Promise<Post> {
    try {
        const res = await axios.get<Post>(`${API}/${id}`);
        return res.data;
    } catch (error) {
        console.error(`Error cant get resource ${id}:`, error);
        throw new Error(getErrorMessage(error));
    }
}

export async function createPost(post: Omit<Post, 'id' | 'date' | 'comments'>): Promise<Post> {
    try {
        const res = await axios.post<Post>(API, post);
        return res.data;
    } catch (error) {
        console.error("Error cant get resource:", error);
        throw new Error(getErrorMessage(error));
    }
}

export async function addComment(postId: number, comment: Comment): Promise<Comment> {
    try {
        const res = await axios.post<Comment>(`${API}/${postId}/comments`, comment);
        return res.data;
    } catch (error) {
        console.error(`Error cant get resource ${postId}:`, error);
        throw new Error(getErrorMessage(error));
    }
}
