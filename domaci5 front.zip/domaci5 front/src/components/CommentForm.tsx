import React, { useState } from 'react';
import { addComment } from '../api/backendHelper.ts';

interface Props {
    postId: number;
    onComment: () => void;
}

const CommentForm: React.FC<Props> = ({ postId, onComment }) => {
    const [author, setAuthor] = useState('');
    const [content, setContent] = useState('');
    const [sending, setSending] = useState(false);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!author.trim() || !content.trim()) return;
        setSending(true);
        await addComment(postId, { author, content });
        setAuthor('');
        setContent('');
        setSending(false);
        onComment();
    };

    return (
        <form onSubmit={handleSubmit} style={{
            marginTop: 22,
            background: '#f8fafd',
            border: '1px solid #e2e4ec',
            borderRadius: 10,
            padding: '18px 20px',
            boxShadow: '0 2px 8px rgba(40,42,60,0.07)',
            maxWidth: 500,
            width: '100%'
        }}>
            <div style={{ fontWeight: 500, fontSize: '1.04em', marginBottom: 6, color: '#2054e7' }}>
                Add a Comment
            </div>
            <div style={{ display: 'flex', gap: 12, marginBottom: 9 }}>
                <input
                    type="text"
                    placeholder="Your Name"
                    value={author}
                    maxLength={32}
                    required
                    style={{ flex: '0 0 160px' }}
                    onChange={e => setAuthor(e.target.value)}
                />
                <input
                    type="text"
                    placeholder="Your Comment"
                    value={content}
                    maxLength={200}
                    required
                    style={{ flex: 1 }}
                    onChange={e => setContent(e.target.value)}
                />
            </div>
            <button type="submit" disabled={sending} className="btn" style={{ width: 120 }}>
                {sending ? "Sending..." : "Comment"}
            </button>
        </form>
    );
};

export default CommentForm;
