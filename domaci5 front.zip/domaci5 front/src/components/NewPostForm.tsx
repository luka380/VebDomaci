import React, { useState } from 'react';
import { createPost } from '../api/backendHelper.ts';

interface Props {
    onDone: () => void;
}

const NewPostForm: React.FC<Props> = ({ onDone }) => {
    const [author, setAuthor] = useState('');
    const [title, setTitle] = useState('');
    const [content, setContent] = useState('');
    const [sending, setSending] = useState(false);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!author.trim() || !title.trim() || !content.trim()) return;
        setSending(true);
        await createPost({ author, title, content });
        setAuthor('');
        setTitle('');
        setContent('');
        setSending(false);
        onDone();
    };

    return (
        <form onSubmit={handleSubmit}
              style={{
                  maxWidth: 600,
                  margin: '32px auto',
                  background: '#f7fafd',
                  border: '1.5px solid #e2e4ec',
                  borderRadius: 12,
                  boxShadow: '0 2px 10px rgba(40,42,60,0.08)',
                  padding: '28px 30px'
              }}>
            <h2 style={{ color: '#2054e7', margin: '0 0 18px 0', textAlign: 'center' }}>Add a New Post</h2>
            <div style={{ display: 'flex', gap: 14, marginBottom: 14 }}>
                <input
                    type="text"
                    placeholder="Author Name"
                    value={author}
                    maxLength={32}
                    required
                    style={{ flex: 1 }}
                    onChange={e => setAuthor(e.target.value)}
                />
                <input
                    type="text"
                    placeholder="Post Title"
                    value={title}
                    maxLength={80}
                    required
                    style={{ flex: 2 }}
                    onChange={e => setTitle(e.target.value)}
                />
            </div>
            <textarea
                placeholder="Write your post here..."
                value={content}
                required
                maxLength={800}
                rows={7}
                style={{
                    width: '100%',
                    resize: 'vertical',
                    marginBottom: 12,
                    fontSize: '1.08em',
                }}
                onChange={e => setContent(e.target.value)}
            />
            <div style={{ display: 'flex', gap: 12, justifyContent: 'flex-end' }}>
                <button type="button" className="btn" style={{ background: '#d5d6e2', color: '#233' }} disabled={sending} onClick={onDone}>
                    Cancel
                </button>
                <button type="submit" className="btn" style={{ minWidth: 120 }} disabled={sending}>
                    {sending ? "Posting..." : "Post"}
                </button>
            </div>
        </form>
    );
};

export default NewPostForm;
