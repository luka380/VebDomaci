import React, { useEffect, useState } from 'react';
import type {Post} from '../types';
import { getPost } from '../api/backendHelper.ts';
import CommentForm from './CommentForm';

interface Props {
    id: number;
    onBack: () => void;
}

const PostDetails: React.FC<Props> = ({ id, onBack }) => {
    const [post, setPost] = useState<Post | null>(null);

    useEffect(() => {
        getPost(id).then(setPost);
    }, [id]);

    if (!post) return <div style={{textAlign:'center', margin:50}}>Loading...</div>;

    return (
        <div style={{
            maxWidth: 700,
            margin: '0 auto',
            background: '#fff',
            borderRadius: 12,
            boxShadow: '0 4px 28px rgba(40,42,60,0.10)',
            padding: '38px 34px 24px 34px',
        }}>
            <button onClick={onBack} className="btn" style={{ marginBottom: 22, background:'#e4e7f4', color:'#132', fontWeight:500 }}>← Back to Posts</button>
            <h1 style={{ color: '#143585', fontSize: '2.15rem', marginBottom: 7 }}>{post.title}</h1>
            <div className="post-meta" style={{ marginBottom: 10 }}>
                by <b>{post.author}</b> &middot; {post.date}
            </div>
            <hr />
            <div className="post-content" style={{
                fontSize: '1.13em',
                color: '#232333',
                lineHeight: 1.6,
                margin: '19px 0 25px 0',
                whiteSpace: 'pre-wrap'
            }}>
                {post.content}
            </div>
            <h3 style={{ color:'#2054e7', marginTop:32 }}>Comments</h3>
            <ul className="comment-list">
                {post.comments.length === 0 && <li style={{color:'#888'}}>No comments yet.</li>}
                {post.comments.map((c, idx) => (
                    <li key={idx} className="comment-item">
                        <span className="comment-author">{c.author}:</span>
                        <span className="comment-content">{c.content}</span>
                    </li>
                ))}
            </ul>
            <CommentForm postId={id} onComment={() => getPost(id).then(setPost)} />
        </div>
    );
};

export default PostDetails;
