package org.example;

import org.glassfish.grizzly.http.server.HttpServer;
import org.glassfish.grizzly.http.server.StaticHttpHandler;
import org.glassfish.jersey.grizzly2.httpserver.GrizzlyHttpServerFactory;
import org.glassfish.jersey.server.ResourceConfig;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Paths;

public class Main {
    public static void main(String[] args) throws IOException, InterruptedException, URISyntaxException {
        ResourceConfig rc = new ResourceConfig()
                .packages("org.example")
                .register(CorsFilter.class)
                .register(AuthFilter.class)
                .register(AuthResource.class)
                .register(PostResource.class);

        HttpServer server = GrizzlyHttpServerFactory.createHttpServer(
                URI.create("http://0.0.0.0:8080/"), rc, false);

        String webRoot = Paths.get(Main.class.getClassLoader().getResource("web").toURI()).toString();
        StaticHttpHandler staticHandler = new StaticHttpHandler(webRoot);

        server.getServerConfiguration().addHttpHandler(staticHandler, "/domaci");

        server.start();
        System.out.println("Server started at http://localhost:8080/ page at http://localhost:8080/domaci/index.html");
        Thread.currentThread().join();
    }
}
