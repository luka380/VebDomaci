package org.example.models;

public class Comment {
    public int id;
    public int postId;
    public String author;
    public String content;
    public String date;
}

