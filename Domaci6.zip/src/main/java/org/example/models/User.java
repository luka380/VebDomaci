package org.example.models;

public class User {
    public String username;
    public String password;
}
