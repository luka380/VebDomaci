package org.example;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.core.Response;
import org.example.models.Comment;
import org.example.models.Post;

import java.sql.*;
import java.util.*;

@Path("/api/posts")
@Produces(MediaType.APPLICATION_JSON)
public class PostResource {
    @OPTIONS
    @Path("{path:.*}")
    public Response options() {
        return Response.ok().build();
    }

    @GET
    public List<Post> getAll() throws Exception {
        List<Post> posts = new ArrayList<>();
        try (Connection conn = Db.getConnection()) {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM posts ORDER BY id DESC");
            while (rs.next()) {
                Post post = new Post();
                post.id = rs.getInt("id");
                post.author = rs.getString("author");
                post.title = rs.getString("title");
                post.content = rs.getString("content");
                post.date = rs.getTimestamp("date").toString();
                post.comments = getCommentsForPost(post.id, conn);
                posts.add(post);
            }
        }
        return posts;
    }

    @GET
    @Path("/{id}")
    public Post getById(@PathParam("id") int id) throws Exception {
        try (Connection conn = Db.getConnection()) {
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM posts WHERE id=?");
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (!rs.next()) throw new WebApplicationException(404);
            Post post = new Post();
            post.id = rs.getInt("id");
            post.author = rs.getString("author");
            post.title = rs.getString("title");
            post.content = rs.getString("content");
            post.date = rs.getTimestamp("date").toString();
            post.comments = getCommentsForPost(post.id, conn);
            return post;
        }
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Post create(Post post, @Context ContainerRequestContext ctx) throws Exception {
        String username = (String) ctx.getProperty("username");
        try (Connection conn = Db.getConnection()) {
            PreparedStatement stmt = conn.prepareStatement(
                    "INSERT INTO posts (author, title, content) VALUES (?, ?, ?) RETURNING id, date");
            stmt.setString(1, username);
            stmt.setString(2, post.title);
            stmt.setString(3, post.content);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                post.id = rs.getInt("id");
                post.author = username;
                post.date = rs.getTimestamp("date").toString();
                post.comments = new ArrayList<>();
            }
        }
        return post;
    }

    @POST
    @Path("/{id}/comments")
    @Consumes(MediaType.APPLICATION_JSON)
    public Comment addComment(@PathParam("id") int postId, Comment comment, @Context ContainerRequestContext ctx) throws Exception {
        String username = (String) ctx.getProperty("username");
        try (Connection conn = Db.getConnection()) {
            PreparedStatement stmt = conn.prepareStatement(
                    "INSERT INTO comments (post_id, author, content) VALUES (?, ?, ?) RETURNING id, date");
            stmt.setInt(1, postId);
            stmt.setString(2, username);
            stmt.setString(3, comment.content);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                comment.id = rs.getInt("id");
                comment.author = username;
                comment.postId = postId;
                comment.date = rs.getTimestamp("date").toString();
            }
        }
        return comment;
    }

    private List<Comment> getCommentsForPost(int postId, Connection conn) throws Exception {
        List<Comment> comments = new ArrayList<>();
        PreparedStatement stmt = conn.prepareStatement("SELECT * FROM comments WHERE post_id = ? ORDER BY id");
        stmt.setInt(1, postId);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            Comment c = new Comment();
            c.id = rs.getInt("id");
            c.postId = postId;
            c.author = rs.getString("author");
            c.content = rs.getString("content");
            c.date = rs.getTimestamp("date").toString();
            comments.add(c);
        }
        return comments;
    }
}
