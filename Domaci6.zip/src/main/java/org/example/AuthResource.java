package org.example;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.example.models.User;

import java.sql.*;

@Path("/api/login")
public class AuthResource {
    @OPTIONS
    @Path("{path:.*}")
    public Response options() {
        return Response.ok().build();
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response login(User user) {
        try (Connection conn = Db.getConnection()) {
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM users WHERE username = ? AND password = ?");
            stmt.setString(1, user.username);
            stmt.setString(2, user.password);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                String token = JwtUtil.generateToken(user.username);
                return Response.ok("{\"token\":\"" + token + "\"}").build();
            } else {
                return Response.status(401).entity("{\"error\":\"Invalid credentials\"}").build();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            return Response.status(500).build();
        }
    }
}

