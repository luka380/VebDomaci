package org.example;

import java.sql.Connection;
import java.sql.DriverManager;

public class Db {
    public static Connection getConnection() throws Exception {
        return DriverManager.getConnection(
                "jdbc:postgresql://localhost:5432/domaci5",
                "luka", "password"
        );
    }
}
