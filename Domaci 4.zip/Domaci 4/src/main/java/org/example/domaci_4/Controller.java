package org.example.domaci_4;

import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.example.domaci_4.Servlet.GetMapping;
import org.example.domaci_4.Servlet.PostMapping;
import org.example.domaci_4.Servlet.UserData;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

public class Controller {
    private final String password;
    private final String frontPage;
    private final String doneFrontPage;
    private final String chosenPage;
    HashMap<String, List<String>> foodPerDay = new HashMap<>();
    ObjectMapper mapper = new ObjectMapper();
    List<String> days = Arrays.asList("ponedeljak", "utorak", "sreda", "cetvrtak", "petak");

    public Controller() {
        password = ResourceReader.readByLine("password.txt").getFirst();
        days.forEach(day -> foodPerDay.put(day, ResourceReader.readByLine(day + ".txt")));

        frontPage = String.join("\n", ResourceReader.readByLine("Pages/FoodMenu.html"));
        doneFrontPage = String.join("\n", ResourceReader.readByLine("Pages/ViewMenu.html"));
        chosenPage = String.join("\n", ResourceReader.readByLine("Pages/FoodAnalytics.html"));
    }

    @GetMapping("/data/availableFood")
    public void availableFood(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().print(mapper.writeValueAsString(foodPerDay));
        response.getWriter().flush();
    }

    @GetMapping("/data/chosenFood")
    public void chosenFood(HttpServletRequest request, HttpServletResponse response, UserData user) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().print(mapper.writeValueAsString(user.mealMap));
    }

    @GetMapping("/data/analytics")
    public void analytics(HttpServletRequest request, HttpServletResponse response, ConcurrentHashMap<HttpSession, UserData> users) throws IOException {
        HttpSession session = request.getSession();

        if (users.containsKey(session) && users.get(session).authenticated) {
            HashMap<String, HashMap<String, Integer>> result = users.values().stream().
                    map(userData -> userData.mealMap).
                    flatMap(hashmap -> hashmap.entrySet().stream()).
                    collect(
                            HashMap::new,
                            (map, entry) -> {
                                if (!map.containsKey(entry.getKey())) {
                                    map.put(entry.getKey(), new HashMap<>());
                                }

                                if (map.get(entry.getKey()).containsKey(entry.getValue())) {
                                    int count = map.get(entry.getKey()).get(entry.getValue()) + 1;
                                    map.get(entry.getKey()).put(entry.getValue(), count);
                                } else {
                                    map.get(entry.getKey()).put(entry.getValue(), 1);
                                }
                            },
                            (a, b) -> {
                            }
                    );

            LinkedHashMap<String, HashMap<String, Integer>> sorted = new LinkedHashMap<>();
            days.forEach(day -> sorted.put(day, result.get(day)));

            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().print(mapper.writeValueAsString(sorted));
            response.getWriter().flush();
        } else
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
    }

    @GetMapping("/")
    public void landingPage(HttpServletRequest request, HttpServletResponse response, UserData user) throws IOException {
        if (user.isFinished) {
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.print(doneFrontPage);
            out.flush();
        } else {
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.print(frontPage);
            out.flush();
        }
    }

    @GetMapping("/odabrana-jela")
    public void analyticsPage(HttpServletRequest request, HttpServletResponse response, UserData user) throws IOException {
        String password = request.getParameter("lozinka");
        if (password != null && password.equals(this.password)) {
            user.authenticated = true;
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.print(chosenPage);
            out.flush();
        } else
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
    }

    @PostMapping("/data/save")
    public void saveChoosenFood(HttpServletRequest request, HttpServletResponse response, UserData user) throws IOException {
        StringBuilder jsonBody = new StringBuilder();
        String line;

        if (user.isFinished) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            return;
        }

        try (BufferedReader reader = request.getReader()) {
            while ((line = reader.readLine()) != null) {
                jsonBody.append(line);
            }
        }
        Map<String, String> mealMap = Arrays.stream(jsonBody.toString().split("&"))
                .map(pair -> pair.split("=", 2))
                .filter(pair -> pair.length == 2)
                .collect(Collectors.toMap(
                        pair -> URLDecoder.decode(pair[0], StandardCharsets.UTF_8),
                        pair -> URLDecoder.decode(pair[1], StandardCharsets.UTF_8)
                ));
        if (mealMap.keySet().equals(foodPerDay.keySet())) {
            user.mealMap.putAll(mealMap);
            user.isFinished = true;
        }
        response.sendRedirect("/");
    }

    @PostMapping("/data/reset")
    public void reset(HttpServletRequest request, HttpServletResponse response, ConcurrentHashMap<HttpSession, UserData> users) {
        HttpSession session = request.getSession();
        if(!users.get(session).authenticated){
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            return;
        }

        users.clear();
        users.put(session, new UserData(new HashMap<>(), false, true));
    }
}
