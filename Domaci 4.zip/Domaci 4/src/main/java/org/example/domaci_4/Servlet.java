package org.example.domaci_4;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@WebServlet(name = "Servlet", value = "/")
public class Servlet extends HttpServlet {
    Map<String, Method> getHandlers = new HashMap<>();
    Map<String, Method> postHandlers = new HashMap<>();
    ConcurrentHashMap<HttpSession, UserData> users = new ConcurrentHashMap<>();
    Controller controller = new Controller();

    @Override
    public void init() {
        for (Method method : Controller.class.getDeclaredMethods()) {
            if (method.isAnnotationPresent(GetMapping.class)) {
                GetMapping annotation = method.getAnnotation(GetMapping.class);
                getHandlers.put(annotation.value(), method);
            }
            if (method.isAnnotationPresent(PostMapping.class)) {
                PostMapping annotation = method.getAnnotation(PostMapping.class);
                postHandlers.put(annotation.value(), method);
            }
        }
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) {
        doSomething(request, response, HttpMethod.GET);
    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) {
        doSomething(request, response, HttpMethod.POST);
    }

    private void doSomething(HttpServletRequest request, HttpServletResponse response, HttpMethod httpMethod) {
        if (!users.containsKey(request.getSession()))
            users.put(request.getSession(), new UserData(new HashMap<>(), false, false));

        Method methodToInvoke = null;

        switch (httpMethod) {
            case GET:
                if (getHandlers.containsKey(request.getRequestURI())) {
                    methodToInvoke = getHandlers.get(request.getRequestURI());
                }
                break;
            case POST:
                if (postHandlers.containsKey(request.getRequestURI())) {
                    methodToInvoke = postHandlers.get(request.getRequestURI());
                }
                break;
            default:
                break;
        }

        if (methodToInvoke == null) {
            response.setStatus(HttpServletResponse.SC_NOT_FOUND);
            return;
        }

        try {
            if (Arrays.stream(methodToInvoke.getParameterTypes()).anyMatch(t -> t == UserData.class)) {
                methodToInvoke.invoke(controller, request, response, users.get(request.getSession()));
            } else if (Arrays.stream(methodToInvoke.getParameterTypes()).anyMatch(t -> t == ConcurrentHashMap.class)) {
                methodToInvoke.invoke(controller, request, response, users);
            } else {
                methodToInvoke.invoke(controller, request, response);
            }
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            throw new RuntimeException(e);
        }
    }

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    public @interface GetMapping {
        String value();
    }

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    public @interface PostMapping {
        String value();
    }

    public static class UserData {
        public HashMap<String, String> mealMap;
        public boolean isFinished;
        public boolean authenticated = false;

        public UserData(HashMap<String, String> hashMap, boolean b) {
            mealMap = hashMap;
            isFinished = b;
        }

        public UserData(HashMap<String, String> hashMap, boolean b, boolean b2) {
            mealMap = hashMap;
            isFinished = b;
            authenticated = b2;
        }
    }

    private enum HttpMethod {
        GET, POST, PUT, DELETE
    }
}