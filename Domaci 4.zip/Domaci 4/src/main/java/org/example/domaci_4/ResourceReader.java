package org.example.domaci_4;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class ResourceReader {
    public static List<String> readByLine(String fileName){
        List<String> strings = new ArrayList<>();
        try {
            InputStream inputStream = ResourceReader.class.getClassLoader().getResourceAsStream(fileName);
            if (inputStream != null) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                String line;
                while ((line = reader.readLine()) != null) {
                    strings.add(line);
                }
                reader.close();
            }
            return strings;
        }
        catch (IOException e) {
            return new ArrayList<>();
        }
    }
}
