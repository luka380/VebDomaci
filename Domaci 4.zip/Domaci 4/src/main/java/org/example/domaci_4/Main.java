package org.example.domaci_4;

import org.apache.catalina.LifecycleException;
import org.apache.catalina.core.StandardContext;
import org.apache.catalina.startup.Tomcat;

import java.io.File;

public class Main {
    public static void main(String[] args) throws LifecycleException {
        String webAppDir = new File("src/main/webapp").getAbsolutePath();

        Tomcat tomcat = new Tomcat();
        tomcat.setPort(8080);
        tomcat.getConnector();

        StandardContext ctx = (StandardContext) tomcat.addWebapp("", webAppDir);

        tomcat.start();
        tomcat.getServer().await();
    }
}
