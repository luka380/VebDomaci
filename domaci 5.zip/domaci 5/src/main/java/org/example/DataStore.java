package org.example;

import org.example.models.Post;
import java.util.*;

public class DataStore {
    public static List<Post> posts = Collections.synchronizedList(new ArrayList<>());
    public static int nextId = 1;
}
