package org.example.models;

import java.util.ArrayList;
import java.util.List;

public class Post {
    public int id;
    public String author;
    public String title;
    public String content;
    public String date;
    public List<Comment> comments = new ArrayList<>();

    public Post() {}
}

