package org.example.models;

public class Comment {
    public String author;
    public String content;

    public Comment() {}
}
