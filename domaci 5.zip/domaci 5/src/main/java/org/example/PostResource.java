package org.example;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import org.example.models.Comment;
import org.example.models.Post;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Path("/api/posts")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class PostResource {

    @GET
    public List<Post> getAllPosts() {
        return DataStore.posts;
    }

    @GET
    @Path("/{id}")
    public Post getPost(@PathParam("id") int id) {
        return DataStore.posts.stream()
                .filter(p -> p.id == id)
                .findFirst()
                .orElseThrow(NotFoundException::new);
    }

    @POST
    public Post createPost(Post post) {
        post.id = DataStore.nextId++;
        post.date = new SimpleDateFormat("dd.MM.yyyy.").format(new Date());
        post.comments = new ArrayList<>();
        DataStore.posts.add(0, post);
        return post;
    }

    @POST
    @Path("/{id}/comments")
    public Comment addComment(@PathParam("id") int id, Comment comment) {
        Post post = getPost(id);
        post.comments.add(comment);
        return comment;
    }
}
