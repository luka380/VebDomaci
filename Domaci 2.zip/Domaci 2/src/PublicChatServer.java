import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class PublicChatServer {
    private static final int PORT = 12345;
    private static final int MAX_MESSAGE_HISTORY = 100;
    private static final Map<String, ClientHandler> clients = new HashMap<>();
    private static final ReentrantReadWriteLock clientsLock = new ReentrantReadWriteLock();
    private static final FixedSizeBuffer<String> buffer = new FixedSizeBuffer<>(MAX_MESSAGE_HISTORY);
    private static final List<String> censoredWords = Arrays.asList("ime", "sta");
    private static final ThreadPoolExecutor threadpool = (ThreadPoolExecutor) Executors.newFixedThreadPool(10);

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Server is running...");

            while (true) {
                Socket clientSocket = serverSocket.accept();
                ClientHandler clientHandler = new ClientHandler(clientSocket);
                threadpool.execute(clientHandler);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void broadcastMessage(String message) {
        clientsLock.readLock().lock();
        clients.values().forEach(clientHandler -> clientHandler.sendMessage(message));
        clientsLock.readLock().unlock();
    }

    public static void addMessageToHistory(String message) {
        buffer.add(message);
    }

    public static List<String> getMessageHistory() {
        return buffer.getBuffer();
    }

    public static String censorMessage(String message) {
        for (String word : censoredWords) {
            message = message.replaceAll("(?i)" + word, word.charAt(0) + "*" + word.substring(2, word.length() - 1) + "*");
        }
        return message;
    }

    public static class ClientHandler implements Runnable {
        private final Socket socket;
        private PrintWriter out;
        private BufferedReader in;
        private String username;

        public ClientHandler(Socket socket) {
            this.socket = socket;
            try {
                this.out = new PrintWriter(socket.getOutputStream(), true);
                this.in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        public String getUsername() {
            return username;
        }

        public void sendMessage(String message) {
            out.println(message);
        }

        public static synchronized boolean tryAdding(String username, ClientHandler clientHandler) {
            clientsLock.readLock().lock();
            if(clients.containsKey(username)){
                clientsLock.readLock().unlock();
                return false;
            }
            clientsLock.readLock().unlock();

            clientsLock.writeLock().lock();
            clients.put(username, clientHandler);
            clientsLock.writeLock().unlock();
            return true;
        }

        @Override
        public void run() {
            try {
                out.println("Enter your username:");
                username = in.readLine();
                while (!tryAdding(username, this)) {
                    out.println("Username is already taken. Please choose a different one:");
                    username = in.readLine();
                }
                out.println("Welcome, " + username + "!");

                getMessageHistory().forEach(this::sendMessage);

                broadcastMessage(username + " has joined the chat.");

                String message;
                while ((message = in.readLine()) != null) {
                    if (message.equalsIgnoreCase("exit")) {
                        break;
                    }
                    String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
                    String formattedMessage = timestamp + " - " + username + ": " + censorMessage(message);
                    addMessageToHistory(formattedMessage);
                    broadcastMessage(formattedMessage);
                }

                clientsLock.writeLock().lock();
                clients.remove(username);
                clientsLock.writeLock().unlock();

                socket.close();
                broadcastMessage(username + " has left the chat.");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
