import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.stream.IntStream;

public class FixedSizeBuffer <T> {
    private final T[] buffer;
    private int head;
    private boolean writeOver;
    private final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();

    @SuppressWarnings("unchecked")
    public FixedSizeBuffer(int capacity) {
        this.buffer = (T[]) new Object[capacity];
        this.head = -1;
        this.writeOver = false;
    }

    public void add(T element) {
        lock.writeLock().lock();
        int newHead = (head + 1) % buffer.length;
        if(head + 1 == buffer.length)
            writeOver = true;
        head = newHead;

        buffer[head] = element;
        lock.writeLock().unlock();
    }

    public List<T> getBuffer() {
        lock.readLock().lock();
        List<T> result = new ArrayList<>();
        if(writeOver)
            IntStream.range(0, buffer.length).forEach(i -> result.add(buffer[(head + i + 1) % buffer.length]));
        else
            IntStream.range(0, head + 1).forEach(i -> result.add(buffer[i]));
        lock.readLock().unlock();
        return result;
    }
}
