public class Main {
    public static void main(String[] args) {
        PublicChatServer.broadcastMessage("Welcome to the chat server!");
    }
}