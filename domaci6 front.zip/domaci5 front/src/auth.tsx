import React, { createContext, useState, useContext } from "react";

interface AuthContextProps {
    user: string;
    token: string;
    login: (username: string, token: string) => void;
    logout: () => void;
}

const AuthContext = createContext<AuthContextProps>({
    user: "",
    token: "",
    login: () => {},
    logout: () => {}
});

export const AuthProvider: React.FC<{children: React.ReactNode}> = ({ children }) => {
    const [user, setUser] = useState(localStorage.getItem("user") || "");
    const [token, setToken] = useState(localStorage.getItem("token") || "");

    const login = (username: string, token: string) => {
        setUser(username);
        setToken(token);
        localStorage.setItem("user", username);
        localStorage.setItem("token", token);
    };

    const logout = () => {
        setUser("");
        setToken("");
        localStorage.removeItem("user");
        localStorage.removeItem("token");
    };

    return (
        <AuthContext.Provider value={{ user, token, login, logout }}>
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = () => useContext(AuthContext);
