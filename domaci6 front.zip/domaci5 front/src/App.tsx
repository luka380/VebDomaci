import React, { useState } from "react";
import LoginForm from "./components/LoginForm";
import PostList from "./components/PostList";
import NewPostForm from "./components/NewPostForm";
import PostDetails from "./components/PostDetails";
import { AuthProvider, useAuth } from "./auth";

const MainApp: React.FC = () => {
    const { user, logout } = useAuth();
    const [selectedPostId, setSelectedPostId] = useState<number | null>(null);
    const [adding, setAdding] = useState(false);

    if (!user) return <LoginForm />;

    return (
        <div className="app-container">
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 12 }}>
                <div style={{ fontSize: "1.15em" }}>Prijavljen kao <b style={{ color: "#2054e7" }}>{user}</b></div>
                <button className="btn" style={{ background: "#e4e7f4", color: "#132" }} onClick={logout}>Logout</button>
            </div>
            {adding ? (
                <NewPostForm onDone={() => { setAdding(false); setSelectedPostId(null); }} />
            ) : selectedPostId ? (
                <PostDetails id={selectedPostId} onBack={() => setSelectedPostId(null)} />
            ) : (
                <PostList onSelect={setSelectedPostId} onNew={() => setAdding(true)} />
            )}
        </div>
    );
};

const App: React.FC = () => (
    <AuthProvider>
        <MainApp />
    </AuthProvider>
);

export default App;
