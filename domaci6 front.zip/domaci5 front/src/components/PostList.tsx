import React, { useEffect, useState } from 'react';
import type {Post} from '../types';
import { getPosts } from '../api/backendHelper.ts';

interface Props {
    onSelect: (id: number) => void;
    onNew: () => void;
}

const PostList: React.FC<Props> = ({ onSelect, onNew }) => {
    const [posts, setPosts] = useState<Post[]>([]);
    const [error, setError] = useState("");

    useEffect(() => {
        getPosts().then(setPosts).catch(err => setError(err.message));
    }, []);

    return (
        <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 25 }}>
                <h1 style={{ margin: 0 }}>All Posts</h1>
                <button className="btn" onClick={onNew}>+ New Post</button>
            </div>
            {error && <div style={{ color: "red" }}>{error}</div>}
            <div className="post-list">
                {posts.length === 0 && <div style={{ color: '#888', padding: 30, textAlign: 'center' }}>No posts yet.</div>}
                {posts.map(post => (
                    <div key={post.id} className="post-card">
                        <div className="post-title" onClick={() => onSelect(post.id!)}>{post.title}</div>
                        <div className="post-meta">by <b>{post.author}</b> &middot; {post.date}</div>
                        <div className="post-content">{post.content.length > 120 ? post.content.slice(0, 120) + "..." : post.content}</div>
                        <button style={{ alignSelf: 'flex-end', marginTop: 6 }} onClick={() => onSelect(post.id!)}>Read more &rarr;</button>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default PostList;
