import React, { useState } from "react";
import { login } from "../api/backendHelper.ts";
import { useAuth } from "../auth";

const LoginForm: React.FC = () => {
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState("");
    const { login: doLogin } = useAuth();

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError("");
        try {
            const token = await login(username, password);
            doLogin(username, token);
        } catch (err: unknown) {
            setError("Login error");
        }
    };

    return (
        <form onSubmit={handleSubmit} style={{ maxWidth: 350, margin: "80px auto", padding: 30, background: "#f6f8fc", borderRadius: 12, boxShadow: "0 2px 18px rgba(0,0,0,0.08)" }}>
            <h2 style={{ textAlign: "center", marginBottom: 20 }}>Login</h2>
            {error && <div style={{ color: "red", marginBottom: 10 }}>{error}</div>}
            <input placeholder="Username" value={username} onChange={e => setUsername(e.target.value)} required style={{ width: "100%", marginBottom: 12 }} />
            <input type="password" placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} required style={{ width: "100%", marginBottom: 20 }} />
            <button type="submit" className="btn" style={{ width: "100%" }}>Login</button>
        </form>
    );
};

export default LoginForm;
