import React, { useState } from 'react';
import { addComment } from '../api/backendHelper.ts';
import { useAuth } from '../auth';

interface Props {
    postId: number;
    onComment: () => void;
}

const CommentForm: React.FC<Props> = ({ postId, onComment }) => {
    const { user } = useAuth();
    const [content, setContent] = useState('');
    const [sending, setSending] = useState(false);
    const [error, setError] = useState('');

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setSending(true);
        try {
            await addComment(postId, content);
            setContent('');
            onComment(); // reload comments in parent
        } catch (err: any) {
            setError(err.message || "Error");
        } finally {
            setSending(false);
        }
    };

    return (
        <form onSubmit={handleSubmit} style={{
            marginTop: 22,
            background: '#f8fafd',
            border: '1px solid #e2e4ec',
            borderRadius: 10,
            padding: '18px 20px',
            boxShadow: '0 2px 8px rgba(40,42,60,0.07)',
            maxWidth: 500,
            width: '100%'
        }}>
            <div style={{ fontWeight: 500, fontSize: '1.04em', marginBottom: 6, color: '#2054e7' }}>
                Add a Comment as <span style={{ color:'#143585' }}>{user}</span>
            </div>
            {error && <div style={{ color: "red", marginBottom: 8 }}>{error}</div>}
            <input
                type="text"
                placeholder="Your Comment"
                value={content}
                maxLength={200}
                required
                style={{ width: "100%", marginBottom: 10 }}
                onChange={e => setContent(e.target.value)}
            />
            <button type="submit" disabled={sending} className="btn" style={{ width: 120 }}>
                {sending ? "Sending..." : "Comment"}
            </button>
        </form>
    );
};

export default CommentForm;
