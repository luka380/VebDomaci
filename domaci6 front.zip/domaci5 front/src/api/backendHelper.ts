import axios from 'axios';
import type {Post, Comment} from '../types';

const API = "http://localhost:8080/api/posts";
const LOGIN = "http://localhost:8080/api/login";

const axiosInstance = axios.create();
axiosInstance.interceptors.request.use(config => {
    const token = localStorage.getItem("token");
    if (token) {
        config.headers = config.headers || {};
        config.headers['Authorization'] = `Bearer ${token}`;
    }
    return config;
});

function getErrorMessage(error: unknown): string {
    if (axios.isAxiosError(error)) {
        if (error.response) {
            return `Error ${error.response.status}: ${error.response.data?.message || error.response.statusText}`;
        } else if (error.request) {
            return "Error no connection with server";
        } else {
            return error.message;
        }
    }
    return String(error);
}

export async function login(username: string, password: string): Promise<string> {
    try {
        const res = await axios.post(LOGIN, { username, password });
        return res.data.token;
    } catch (error) {
        throw new Error(getErrorMessage(error));
    }
}

export async function getPosts(): Promise<Post[]> {
    try {
        const res = await axiosInstance.get<Post[]>(API);
        return res.data;
    } catch (error) {
        throw new Error(getErrorMessage(error));
    }
}

export async function getPost(id: number): Promise<Post> {
    try {
        const res = await axiosInstance.get<Post>(`${API}/${id}`);
        return res.data;
    } catch (error) {
        throw new Error(getErrorMessage(error));
    }
}

export async function createPost(post: Omit<Post, 'id' | 'author' | 'date' | 'comments'>): Promise<Post> {
    try {
        const res = await axiosInstance.post<Post>(API, post);
        return res.data;
    } catch (error) {
        throw new Error(getErrorMessage(error));
    }
}

export async function addComment(postId: number, content: string): Promise<Comment> {
    try {
        const res = await axiosInstance.post<Comment>(`${API}/${postId}/comments`, { content });
        return res.data;
    } catch (error) {
        throw new Error(getErrorMessage(error));
    }
}
