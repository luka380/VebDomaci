export interface Comment {
    id?: number;
    postId?: number;
    author: string;
    content: string;
    date?: string;
}

export interface Post {
    id?: number;
    author: string;
    title: string;
    content: string;
    date?: string;
    comments: Comment[];
}
