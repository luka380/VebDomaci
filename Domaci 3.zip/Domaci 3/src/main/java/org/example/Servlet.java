package org.example;

import java.io.IOException;
import java.net.Socket;

public interface Servlet {
    void accept(Socket socket) throws IOException, InterruptedException;
}
