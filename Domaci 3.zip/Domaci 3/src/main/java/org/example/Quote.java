package org.example;

record Quote(String author, String quote) {
}
