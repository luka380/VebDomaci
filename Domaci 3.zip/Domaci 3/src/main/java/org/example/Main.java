package org.example;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class Main {

    public static void main(String[] args) {
        Server quoteServer = new Server(8088, 20, new QuoteServlet());
        Server qouteOfTheDayServer = new Server(8089, 20, new QuoteOfTheDayServlet());
        System.out.println("Available commands: start stop exit, quote of the day will be chosen every 5th quote saved");
        Scanner scanner = new Scanner(System.in);
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            if (line.startsWith("exit")) {
                if (quoteServer.isRunning()) {
                    quoteServer.stop();
                    qouteOfTheDayServer.stop();
                }
                break;
            } else if (line.startsWith("start")) {
                quoteServer.start();
                qouteOfTheDayServer.start();
            } else if (line.startsWith("stop")) {
                quoteServer.stop();
                qouteOfTheDayServer.stop();
            }
        }
    }

    private static class QuoteServlet implements Servlet {
        private final ObjectMapper mapper = new ObjectMapper();
        private final List<Quote> quotes = new ArrayList<>();
        private final ReentrantReadWriteLock quotesLock = new ReentrantReadWriteLock();

        @Override
        public void accept(Socket socket) throws IOException {
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            OutputStream out = socket.getOutputStream();

            Server.HttpRequest request = Server.HttpRequest.fromInputStream(in);

            if (request.getMethod().equals("GET") && request.getPath().equals("/quotesData")) {
                sendQuotesResponse(out);
            }
            else if (request.getMethod().equals("GET") && request.getPath().equals("/quotesInternal")) {
                Server.HttpResponse response = new Server.HttpResponse(200);
                quotesLock.readLock().lock();
                response.body = mapper.writeValueAsString(quotes);
                quotesLock.readLock().unlock();
                response.headers.put("Content-Type", "application/json");
                response.headers.put("Content-Length", String.valueOf(response.body.length()));
                out.write(response.toString().getBytes(StandardCharsets.UTF_8));
                out.flush();
            }
            else if (request.getMethod().equals("POST") && request.getPath().equals("/save-quote")) {
                saveQuote(out, mapper.readValue(request.body, Quote.class));
            }
            else if (request.getMethod().equals("GET") && request.getPath().equals("/quotes"))
                sendHtmlPage(out);
            else {
                Server.HttpResponse response = new Server.HttpResponse(404);
                out.write(response.toString().getBytes(StandardCharsets.UTF_8));
                out.flush();
            }

        }

        private void sendHtmlPage(OutputStream out) throws IOException {
            Server.HttpResponse response = new Server.HttpResponse(200);
            response.body = java.nio.file.Files.readString(Path.of("src/main/resources/FrontPage.html"));
            response.headers.put("Content-Type", "text/html");
            response.headers.put("Content-Length", String.valueOf(response.body.length()));
            out.write(response.toString().getBytes(StandardCharsets.UTF_8));
            out.flush();
        }

        private void sendQuotesResponse(OutputStream out) throws IOException {
            Server.HttpResponse response = new Server.HttpResponse(200);
            quotesLock.readLock().lock();
            response.body = mapper.writeValueAsString(new Data(getQuoteOfTheDay(), new ArrayList<>(quotes)));
            quotesLock.readLock().unlock();
            response.headers.put("Content-Type", "application/json");
            response.headers.put("Content-Length", String.valueOf(response.body.length()));
            out.write(response.toString().getBytes(StandardCharsets.UTF_8));
            out.flush();
        }

        private void saveQuote(OutputStream out, Quote quote) throws IOException {
            quotesLock.writeLock().lock();
            quotes.add(quote);
            quotesLock.writeLock().unlock();

            Server.HttpResponse response = new Server.HttpResponse(303);
            response.headers.put("Location", "/quotes");

            out.write(response.toString().getBytes(StandardCharsets.UTF_8));
            out.flush();
        }

        private String getQuoteOfTheDay() {
            Server.HttpRequest request = new Server.HttpRequest("GET", "/quote-of-the-day");
            Server.HttpResponse response = Server.OneTimeHttpClient("localhost", 8089, request);
            if (response != null) {
                try {
                    Quote quote = mapper.readValue(response.body, Quote.class);
                    return quote.author() + ": " + quote.quote();
                } catch (JsonProcessingException e) {
                    return "No quote found";
                }
            }
            return "No quote found";
        }
    }

    private static class QuoteOfTheDayServlet implements Servlet {
        private final ObjectMapper mapper = new ObjectMapper();
        private final List<Quote> quotes = Collections.synchronizedList(new ArrayList<>());
        private int QuoteTTLcounter = 0;
        private int QuoteIndex = -1;

        @Override
        public void accept(Socket socket) throws IOException {
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            OutputStream out = socket.getOutputStream();

            Server.HttpRequest request = Server.HttpRequest.fromInputStream(in);

            if (request.getMethod().equals("GET") && request.getPath().equals("/quote-of-the-day")) {
                sendQuoteResponse(out);
            }
        }

        private void sendQuoteResponse(OutputStream out) throws IOException {
            if (quotes.isEmpty() || QuoteTTLcounter == 0) {
                getQuotes();
            }

            String quote = "No quote found";
            if (!quotes.isEmpty()) {
                if (QuoteTTLcounter == 0) {
                    QuoteIndex = new Random().nextInt(quotes.size());
                    QuoteTTLcounter = 5;
                }
                quote = mapper.writeValueAsString(quotes.get(QuoteIndex));
                QuoteTTLcounter--;
            }

            Server.HttpResponse response = new Server.HttpResponse(200);
            response.body = quote;
            response.headers.put("Content-Type", "application/json");
            response.headers.put("Content-Length", String.valueOf(response.body.length()));

            out.write(response.toString().getBytes(StandardCharsets.UTF_8));
            out.flush();
        }

        private void getQuotes() throws IOException {
            Server.HttpRequest request = new Server.HttpRequest("GET", "/quotesInternal");
            Server.HttpResponse response = Server.OneTimeHttpClient("localhost", 8088, request);
            if (response != null) {
                List<Quote> quotes2 = mapper.readValue(response.body, new TypeReference<>() {
                });
                quotes.addAll(quotes2);
            }
        }
    }
}
