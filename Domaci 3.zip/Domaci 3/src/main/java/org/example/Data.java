package org.example;

import java.util.List;

record Data(String quoteOfTheDay, List<Quote> quotes) {
}
