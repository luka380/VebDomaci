package org.example;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

public class Server {
    private final int port;
    private final ThreadPoolExecutor threadPool;
    private Thread serverThread;
    private boolean running = false;
    private final Servlet servlet;
    private ServerSocket serverSocket;

    public Server(int port, int threadPoolSize, Servlet servlet) {
        this.port = port;
        this.threadPool = (ThreadPoolExecutor) Executors.newFixedThreadPool(threadPoolSize);
        this.servlet = servlet;
    }

    public void start() {
        if (running) {
            System.out.println("Server is already running");
            return;
        }

        System.out.println("Starting server on port " + port + " with thread count " + threadPool.getPoolSize());

        serverThread = new Thread(() -> {
            try (ServerSocket serverSocket = new ServerSocket(port)) {
                this.serverSocket = serverSocket;
                while (!Thread.currentThread().isInterrupted()) {
                    Socket clientSocket = serverSocket.accept();
                    if (!threadPool.isShutdown())
                        threadPool.submit(() -> {
                            try (Socket socket = clientSocket) {
                                servlet.accept(socket);
                            } catch (IOException e) {
                                System.out.println("Connection error: " + e.getMessage());
                            } catch (InterruptedException i) {
                                System.out.println("Thread interrupted");
                            }
                        });
                }
            } catch (IOException e) {
                if (Thread.currentThread().isInterrupted()) {
                    System.out.println("Server stopped accepting connections");
                } else {
                    e.printStackTrace();
                }
            }
        });
        serverThread.start();
        running = true;
    }

    public void stop() {
        if (!running) {
            System.out.println("Warning server already stopped");
            return;
        }

        try {
            serverSocket.close();
        } catch (IOException _) {
        }
        System.out.println("Stopping server");
        running = false;
        serverThread.interrupt();
        threadPool.shutdown();
        System.out.println("Server stopped");
    }

    public boolean isRunning() {
        return running;
    }

    public Servlet getServlet() {
        return servlet;
    }

    public static class HttpMessage {
        protected Map<String, String> headers = new HashMap<>();
        protected String body = "";

        public void addHeader(String key, String value) {
            headers.put(key, value);
        }

        public String getHeader(String key) {
            return headers.get(key);
        }

        public void setBody(String body) {
            this.body = body;
        }

        public String getBody() {
            return body;
        }

        public Map<String, String> getHeaders() {
            return headers;
        }
    }

    public static class HttpRequest extends HttpMessage {
        private final String method;
        private final String path;
        private String httpVersion = "HTTP/1.0";

        public HttpRequest(String method, String path) {
            this.method = method.toUpperCase();
            this.path = path;
        }

        public String getMethod() {
            return method;
        }

        public String getPath() {
            return path;
        }

        public void setHttpVersion(String httpVersion) {
            this.httpVersion = httpVersion;
        }

        public String getHttpVersion() {
            return httpVersion;
        }

        public static HttpRequest fromString(String rawRequest) {
            String[] lines = rawRequest.split("\r\n");
            String[] requestLine = lines[0].split(" ");

            if (requestLine.length < 3) {
                throw new IllegalArgumentException("Invalid HTTP request format.");
            }

            HttpRequest request = new HttpRequest(requestLine[0], requestLine[1]);
            request.setHttpVersion(requestLine[2]);

            int i = 1;
            while (i < lines.length && !lines[i].isEmpty()) {
                String[] headerParts = lines[i].split(": ", 2);
                if (headerParts.length == 2) {
                    request.addHeader(headerParts[0], headerParts[1]);
                }
                i++;
            }

            if (i + 1 < lines.length) {
                request.setBody(lines[i + 1]);
            }

            return request;
        }

        public static HttpRequest fromInputStream(BufferedReader in) throws IOException {
            StringBuilder requestBuilder = new StringBuilder();
            String line;
            int contentLength = 0;

            while ((line = in.readLine()) != null && !line.isEmpty()) {
                requestBuilder.append(line).append("\r\n");

                if (line.startsWith("Content-Length:")) {
                    contentLength = Integer.parseInt(line.split(": ")[1]);
                }
            }
            requestBuilder.append("\r\n");

            StringBuilder bodyBuilder = new StringBuilder();
            if (contentLength > 0) {
                char[] bodyChars = new char[contentLength];
                in.read(bodyChars, 0, contentLength);
                bodyBuilder.append(bodyChars);
            }

            requestBuilder.append(bodyBuilder);

            return HttpRequest.fromString(requestBuilder.toString());
        }

        @Override
        public String toString() {
            StringBuilder requestString = new StringBuilder();
            requestString.append(method).append(" ").append(path).append(" ").append(httpVersion).append("\r\n");

            for (Map.Entry<String, String> entry : headers.entrySet()) {
                requestString.append(entry.getKey()).append(": ").append(entry.getValue()).append("\r\n");
            }

            requestString.append("\r\n").append(body);
            return requestString.toString();
        }
    }

    public static class HttpResponse extends HttpMessage {
        private final int statusCode;
        private String statusMessage;
        private String httpVersion = "HTTP/1.0";

        private static final Map<Integer, String> STATUS_MESSAGES = new HashMap<>() {{
            put(200, "OK");
            put(201, "Created");
            put(204, "No Content");
            put(303, "See Other");
            put(400, "Bad Request");
            put(404, "Not Found");
            put(500, "Internal Server Error");
        }};

        public HttpResponse(int statusCode) {
            this.statusCode = statusCode;
            this.statusMessage = STATUS_MESSAGES.getOrDefault(statusCode, "Unknown Status");
        }

        public int getStatusCode() {
            return statusCode;
        }

        public String getStatusMessage() {
            return statusMessage;
        }

        public void setHttpVersion(String httpVersion) {
            this.httpVersion = httpVersion;
        }

        public String getHttpVersion() {
            return httpVersion;
        }

        public static HttpResponse fromString(String rawResponse) {
            String[] lines = rawResponse.split("\r\n");
            String[] statusLine = lines[0].split(" ", 3);

            if (statusLine.length < 3) {
                throw new IllegalArgumentException("Invalid HTTP response format.");
            }

            HttpResponse response = new HttpResponse(Integer.parseInt(statusLine[1]));
            response.statusMessage = statusLine[2];
            response.setHttpVersion(statusLine[0]);

            int i = 1;
            while (i < lines.length && !lines[i].isEmpty()) {
                String[] headerParts = lines[i].split(": ", 2);
                if (headerParts.length == 2) {
                    response.addHeader(headerParts[0], headerParts[1]);
                }
                i++;
            }

            if (i + 1 < lines.length) {
                response.setBody(lines[i + 1]);
            }

            return response;
        }

        public static HttpResponse fromInputStream(BufferedReader in) throws IOException {
            StringBuilder responseBuilder = new StringBuilder();
            String statusLine = in.readLine();
            if (statusLine == null) return null;
            responseBuilder.append(statusLine).append("\r\n");

            String line;
            int contentLength = 0;
            while ((line = in.readLine()) != null && !line.isEmpty()) {
                responseBuilder.append(line).append("\r\n");

                if (line.startsWith("Content-Length:")) {
                    contentLength = Integer.parseInt(line.split(": ")[1]);
                }
            }
            responseBuilder.append("\r\n");

            if (contentLength > 0) {
                char[] bodyChars = new char[contentLength];
                in.read(bodyChars, 0, contentLength);
                responseBuilder.append(new String(bodyChars));
            }

            return HttpResponse.fromString(responseBuilder.toString());
        }

        @Override
        public String toString() {
            StringBuilder responseString = new StringBuilder();
            responseString.append(httpVersion).append(" ").append(statusCode).append(" ").append(statusMessage).append("\r\n");

            for (Map.Entry<String, String> entry : headers.entrySet()) {
                responseString.append(entry.getKey()).append(": ").append(entry.getValue()).append("\r\n");
            }

            responseString.append("\r\n").append(body);
            return responseString.toString();
        }
    }

    public static HttpResponse OneTimeHttpClient(String host, int port, HttpRequest request) {
        try (Socket socket = new Socket(host, port);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             OutputStream out = socket.getOutputStream()) {

            out.write(request.toString().getBytes(StandardCharsets.UTF_8));
            out.flush();

            return HttpResponse.fromInputStream(in);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
